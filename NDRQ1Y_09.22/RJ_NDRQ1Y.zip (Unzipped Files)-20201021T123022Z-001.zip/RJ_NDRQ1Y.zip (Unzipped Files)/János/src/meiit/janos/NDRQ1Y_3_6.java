package meiit.janos;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class NDRQ1Y_3_6 {

	public static void main(String[] args) {
		

	}
	
	 public class Auto implements Serializable{
		 public Auto(String string, String string2, int i) {
			 String r = null;
			this.rsz = r;
			 String t = null;
			this.tipus = t;
			 int a = 0;
			this.ar = a; 
		}
		private static final long serialVersionUID = 1L;
		 String rsz;
		 String tipus;
		 int ar;
	 }

	 
	// public  void Auto (String r, String t, int a){
	//	 this.rsz = r;
		// this.tipus = t;
		// this.ar = a; 
		
//	 }
	 
	 public void hf4(){
		 String sor;
		 Auto[] autoim = { new Auto("R11","Opel",333), new Auto("R12","Fiat",233),new Auto("R14","Skoda",364)};
		 
		 
		 try {
			 ObjectOutputStream kifile = new ObjectOutputStream(
					 new FileOutputStream ("Autok.dat"));
		 }
	 
	 
}
}
